export const loadGoogleMaps = () => {
  return new Promise((resolve) => {
    if (window.google) {
      resolve(window.google);
    } else {
      const interval = setInterval(() => {
        if (window.google) {
          clearInterval(interval);
          resolve(window.google);
        }
      }, 500);
    }
  });
};