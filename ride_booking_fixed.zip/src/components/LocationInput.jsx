import { useEffect, useRef } from "react";
import { loadGoogleMaps } from "../utils/googleMapsLoader";

const LocationInput = ({ placeholder, setLocation }) => {
  const inputRef = useRef(null);

  useEffect(() => {
    loadGoogleMaps().then((google) => {
      const autocomplete = new google.maps.places.Autocomplete(inputRef.current);

      autocomplete.addListener("place_changed", () => {
        const place = autocomplete.getPlace();

        if (!place.geometry) return;

        setLocation({
          address: place.formatted_address,
          lat: place.geometry.location.lat(),
          lng: place.geometry.location.lng(),
        });
      });
    });
  }, []);

  return <input ref={inputRef} type="text" placeholder={placeholder} />;
};

export default LocationInput;