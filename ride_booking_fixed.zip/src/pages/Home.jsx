import { useState } from "react";
import LocationInput from "../components/LocationInput";
import { calculateDistance } from "../utils/distance";

const Home = () => {
  const [pickup, setPickup] = useState(null);
  const [drop, setDrop] = useState(null);
  const [distance, setDistance] = useState("");
  const [duration, setDuration] = useState("");

  const handleCalculate = async () => {
    if (!pickup || !drop) {
      alert("Please select both locations");
      return;
    }

    try {
      const result = await calculateDistance(pickup, drop);
      setDistance(result.distance);
      setDuration(result.duration);
    } catch (err) {
      console.error(err);
      alert("Error calculating distance");
    }
  };

  return (
    <div style={{ padding: "20px" }}>
      <h2>Ride Booking</h2>

      <LocationInput placeholder="Enter Pickup Location" setLocation={setPickup} />
      <LocationInput placeholder="Enter Drop Location" setLocation={setDrop} />

      <button onClick={handleCalculate}>Calculate Distance</button>

      {distance && (
        <div>
          <p>Distance: {distance}</p>
          <p>Duration: {duration}</p>
        </div>
      )}
    </div>
  );
};

export default Home;