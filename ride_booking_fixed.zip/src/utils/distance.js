export const calculateDistance = (pickup, drop) => {
  return new Promise((resolve, reject) => {
    if (!window.google) {
      reject("Google Maps not loaded");
      return;
    }

    const service = new window.google.maps.DistanceMatrixService();

    service.getDistanceMatrix(
      {
        origins: [new window.google.maps.LatLng(pickup.lat, pickup.lng)],
        destinations: [new window.google.maps.LatLng(drop.lat, drop.lng)],
        travelMode: window.google.maps.TravelMode.DRIVING,
      },
      (response, status) => {
        if (status !== "OK") {
          reject(status);
        } else {
          const result = response.rows[0].elements[0];

          resolve({
            distance: result.distance.text,
            duration: result.duration.text,
          });
        }
      }
    );
  });
};